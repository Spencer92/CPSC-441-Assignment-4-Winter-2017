The file is in the package router.router
This shouldn't be a problem as all of the files are in the same package

The prevNode doesn't work, and therefore only the node and distance are displayed.

Spencer Maslen